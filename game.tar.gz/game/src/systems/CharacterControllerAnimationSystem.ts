import { System } from "@engine/core/base/System";


export class CharacterControllerAnimationSystem extends System {
}




